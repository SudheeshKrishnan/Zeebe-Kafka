package io.flowing.retail.checkout.domain;

public class RequstParamPojo {
	private String payment;

	public RequstParamPojo()
	{
		
	}
	
	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}
	
	

}
