package com.example.poc.zeebe;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import io.zeebe.client.ZeebeClient;

@SpringBootApplication
public class ZeebeApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(ZeebeApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(ZeebeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

	}

	@Bean
	public ZeebeClient getZeebeClient() {

		return ZeebeClient.newClientBuilder().brokerContactPoint("localhost:26500").usePlaintext()
				.build();

			

	}

}
