package com.example.poc.zeebe;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.response.DeploymentEvent;
import io.zeebe.client.api.response.WorkflowInstanceEvent;
import io.zeebe.client.api.worker.JobWorker;

@RestController
public class GreetingController {

	private static final Logger logger = LoggerFactory.getLogger(ZeebeApplication.class);
	@Autowired
	ZeebeClient client;

	@GetMapping("/deploy")
	public String deploy() {
		final DeploymentEvent deployment = client.newDeployCommand().addResourceFromClasspath("order-process.bpmn")
				.send().join();
		final int version = deployment.getWorkflows().get(0).getVersion();
		logger.info("Workflow deployed. Version: " + version);

//		final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand().bpmnProcessId("order-process")
//				.latestVersion().send().join();
//
//		final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();
//		logger.info("Workflow instance created. Key: " + workflowInstanceKey);

		return String.valueOf(version);

	}

	@GetMapping("/instance")
	public String getInstace() {
		final Map<String, Object> data = new HashMap<>();
		data.put("orderId", 31243);
		data.put("orderItems", Arrays.asList(435, 182, 376));

		final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand().bpmnProcessId("order-process")
				.latestVersion().variables(data).send().join();

		final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();
		logger.info("Workflow instance created. Key: " + workflowInstanceKey);
		return String.valueOf(workflowInstanceKey);

	}

	@GetMapping("/job/{name}")
	public String getworker(@PathVariable("name") String name) {

		final JobWorker jobWorker = client.newWorker().jobType(name).handler((jobClient, job) -> {
			logger.info(name);
			logger.info(String.valueOf(job.getRetries()));

			final Map<String, Object> variables = job.getVariablesAsMap();

			logger.info("Process order: " + variables.get("orderId"));
			double price = 46.50;
			logger.info("Collect money: $" + price);

			final Map<String, Object> result = new HashMap<>();
			result.put("totalPrice", price);
			jobClient.newCompleteCommand(job.getKey()).variables(result).send().join();
		}).fetchVariables("orderId").open();

		// jobWorker.close();
		return "done";

	}

}